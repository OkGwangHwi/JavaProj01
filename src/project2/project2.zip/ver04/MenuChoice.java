package project2.ver04;

import java.util.Scanner;

public class MenuChoice {
	
}
