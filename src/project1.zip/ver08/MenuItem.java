package ver08;

public interface MenuItem {

	int INPUT = 1,SEARCH = 2,DELETE = 3,SHOWALL = 4,EXIT = 5;
}
