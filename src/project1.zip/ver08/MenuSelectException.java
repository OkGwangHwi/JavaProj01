package ver08;

public class MenuSelectException extends Exception{
	
	public MenuSelectException(String msg) {
		super(msg);
	}
}
