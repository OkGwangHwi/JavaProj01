package ver06;

public interface SubMenuItem {

	int NOMAL = 1,SCHOOL = 2,COMPANY = 3;
}
