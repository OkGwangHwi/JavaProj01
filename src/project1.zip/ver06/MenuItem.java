package ver06;

public interface MenuItem {

	int INPUT = 1,SEARCH = 2,DELETE = 3,EXIT = 4;
}
