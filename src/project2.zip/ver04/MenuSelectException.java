package project2.ver04;

public class MenuSelectException extends Exception{
	public MenuSelectException() {
		super("1~5사이의 숫자를 입력하세요.");
		}
	}
