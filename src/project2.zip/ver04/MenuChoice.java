package project2.ver04;

import java.util.Scanner;
import project2.BankingSystemVer01;;

public interface MenuChoice{
	int MAKE = 1,DEPOSIT = 2,WITHDRAW = 3,INQUIRE = 4,EXIT = 5;
}


