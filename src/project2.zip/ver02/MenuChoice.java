package project2.ver02;

import java.util.Scanner;
import project2.BankingSystemVer01;;

public class MenuChoice {
	
}
