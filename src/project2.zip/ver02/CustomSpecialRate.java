package project2.ver02;

public class CustomSpecialRate {

	private int gradePlus;

	public CustomSpecialRate(int gradePlus) {
		this.gradePlus = gradePlus;
	}

	public int getGradePlus() {
		return gradePlus;
	}

	public void setGradePlus(int gradePlus) {
		this.gradePlus = gradePlus;
	}
	
	
}
